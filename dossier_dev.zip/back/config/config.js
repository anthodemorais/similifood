module.exports = {
    secret: "similifood"
}