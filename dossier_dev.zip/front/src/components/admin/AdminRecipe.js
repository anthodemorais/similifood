import React, { Component } from 'react';

class AdminRecipe extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return (
            <form></form>
        );
    }
}
 
export default AdminRecipe;