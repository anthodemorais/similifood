import React, { Component } from 'react';

class Concept extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return (
            <div className="container">

            </div>
        );
    }
}
 
export default Concept;